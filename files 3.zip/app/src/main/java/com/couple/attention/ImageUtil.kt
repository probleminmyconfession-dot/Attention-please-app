package com.couple.attention

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.min

object ImageUtil {

    private fun loadBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sample = 1
            while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            var deg = 0
            try {
                cr.openInputStream(uri)?.use {
                    val ex = android.media.ExifInterface(it)
                    val o = ex.getAttributeInt(
                        android.media.ExifInterface.TAG_ORIENTATION,
                        android.media.ExifInterface.ORIENTATION_NORMAL
                    )
                    deg = when (o) {
                        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                }
            } catch (e: Exception) {
            }

            if (deg != 0) {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            } else {
                decoded
            }
        } catch (e: Exception) {
            null
        }
    }

    // Profile photo: beech se chaukor katke 160x160 banata hai, chhota text (base64) mein
    fun profileBase64(ctx: Context, uri: Uri): String? {
        val src = loadBitmap(ctx, uri, 400) ?: return null
        return try {
            val side = min(src.width, src.height)
            val x = (src.width - side) / 2
            val y = (src.height - side) / 2
            val square = Bitmap.createBitmap(src, x, y, side, side)
            val small = Bitmap.createScaledBitmap(square, 160, 160, true)
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 75, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    fun decode(b64: String): Bitmap? {
        return try {
            val b = Base64.decode(b64, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(b, 0, b.size)
        } catch (e: Exception) {
            null
        }
    }
}
