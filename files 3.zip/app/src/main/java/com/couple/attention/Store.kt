package com.couple.attention

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    // group: "family" (default) ya "couple"
    data class Member(
        val name: String,
        val code: String,
        val group: String = "family"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("attn", Context.MODE_PRIVATE)

    private fun gen(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { chars.random() }.joinToString("")
    }

    fun myCode(c: Context): String {
        val sp = prefs(c)
        var code = sp.getString("me", null)
        if (code == null) {
            code = gen()
            sp.edit().putString("me", code).apply()
        }
        return code
    }

    fun section(c: Context): String = prefs(c).getString("section", "couple") ?: "couple"

    fun setSection(c: Context, s: String) {
        prefs(c).edit().putString("section", s).apply()
    }

    fun profileName(c: Context): String = prefs(c).getString("pname", "") ?: ""

    fun profilePhoto(c: Context): String = prefs(c).getString("pphoto", "") ?: ""

    fun saveProfile(c: Context, name: String, photo: String) {
        prefs(c).edit().putString("pname", name).putString("pphoto", photo).apply()
    }

    fun members(c: Context): List<Member> {
        val raw = prefs(c).getString("members", "[]") ?: "[]"
        val out = ArrayList<Member>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Member(o.getString("name"), o.getString("code"), o.optString("group", "family")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveMembers(c: Context, list: List<Member>) {
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("name", m.name)
            o.put("code", m.code)
            o.put("group", m.group)
            arr.put(o)
        }
        prefs(c).edit().putString("members", arr.toString()).apply()
    }
}
