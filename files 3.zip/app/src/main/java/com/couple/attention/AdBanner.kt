package com.couple.attention

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

object AdConfig {
    // true  = Google ke test ads (turant dikhte hain, apne ads par click karna safe hai)
    // false = aapke asli AdMob ads
    const val USE_TEST_ADS = false

    const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
    const val REAL_BANNER = "ca-app-pub-4767063739583768/8379144233"
}

@Composable
fun AdBanner() {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = if (AdConfig.USE_TEST_ADS) AdConfig.TEST_BANNER else AdConfig.REAL_BANNER
                loadAd(AdRequest.Builder().build())
            }
        })
    }
}
