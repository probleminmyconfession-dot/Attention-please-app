package com.couple.attention

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore

object Repo {
    data class Note(val text: String, val ts: Long)

    private var appCtx: Context? = null
    private var started = false
    private var baselined = false
    private var notesBaselined = false
    private val lastHandled = HashMap<String, Long>()
    private val lastNoteTs = HashMap<String, Long>()

    lateinit var me: String

    var members by mutableStateOf(listOf<Store.Member>())
        private set

    // jinhone MERA code add kiya hai (mutual match ke liye)
    var addedMe by mutableStateOf(setOf<String>())
        private set

    // unki profile photos (code -> base64)
    var profiles by mutableStateOf(mapOf<String, String>())
        private set

    // har bheje wale ka aakhri chhota message
    var notes by mutableStateOf(mapOf<String, Note>())
        private set

    var myName by mutableStateOf("")
        private set
    var myPhoto by mutableStateOf("")
        private set

    private fun db() = FirebaseFirestore.getInstance()

    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val n = cm.activeNetwork ?: return false
            val c = cm.getNetworkCapabilities(n) ?: return false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    fun start(c: Context) {
        appCtx = c.applicationContext
        if (started) return
        started = true
        val ctx = appCtx!!
        me = Store.myCode(ctx)
        members = Store.members(ctx)
        myName = Store.profileName(ctx)
        myPhoto = Store.profilePhoto(ctx)

        db().collection("users").whereArrayContains("contacts", me)
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    addedMe = snap.documents.map { it.id }.toSet()
                    profiles = snap.documents.mapNotNull { d ->
                        val p = d.getString("photo")
                        if (p != null && p.isNotEmpty()) d.id to p else null
                    }.toMap()
                }
            }

        // horn wale alerts
        db().collection("pings").whereEqualTo("to", me)
            .addSnapshotListener { snap, _ ->
                if (snap == null || snap.metadata.isFromCache) return@addSnapshotListener
                for (ch in snap.documentChanges) {
                    if (ch.type == DocumentChange.Type.REMOVED) continue
                    val d = ch.document
                    val from = d.getString("from") ?: continue
                    val ts = d.getLong("ts") ?: continue
                    val last = lastHandled[from] ?: 0L
                    if (ts <= last) continue
                    lastHandled[from] = ts
                    if (!baselined) continue
                    val m = members.firstOrNull { it.code == from } ?: continue
                    Alerts.trigger(ctx, m.name)
                }
                baselined = true
            }

        // chhote messages (Miss you etc.) - sirf notification, horn nahi
        db().collection("notes").whereEqualTo("to", me)
            .addSnapshotListener { snap, _ ->
                if (snap == null || snap.metadata.isFromCache) return@addSnapshotListener
                for (ch in snap.documentChanges) {
                    if (ch.type == DocumentChange.Type.REMOVED) continue
                    val d = ch.document
                    val from = d.getString("from") ?: continue
                    val ts = d.getLong("ts") ?: continue
                    val last = lastNoteTs[from] ?: 0L
                    if (ts <= last) continue
                    lastNoteTs[from] = ts
                    val text = d.getString("text") ?: ""
                    notes = notes + (from to Note(text, ts))
                    if (!notesBaselined) continue
                    val m = members.firstOrNull { it.code == from } ?: continue
                    Alerts.note(ctx, from, m.name, text, profiles[from])
                }
                notesBaselined = true
            }

        publishContacts()
    }

    private fun publishContacts() {
        try {
            db().collection("users").document(me).set(
                hashMapOf<String, Any>(
                    "contacts" to members.map { it.code },
                    "photo" to myPhoto
                )
            )
        } catch (e: Exception) {
        }
    }

    fun setProfile(name: String, photo: String) {
        myName = name
        myPhoto = photo
        appCtx?.let { Store.saveProfile(it, name, photo) }
        publishContacts()
    }

    fun addMember(name: String, code: String, group: String = "family") {
        members = members + Store.Member(name, code, group)
        appCtx?.let { Store.saveMembers(it, members) }
        publishContacts()
    }

    fun removeMember(code: String) {
        members = members.filter { it.code != code }
        appCtx?.let { Store.saveMembers(it, members) }
        publishContacts()
    }

    fun send(codes: List<String>) {
        val now = System.currentTimeMillis()
        for (c in codes) {
            db().collection("pings").document(me + "_" + c)
                .set(mapOf("from" to me, "to" to c, "ts" to now))
        }
    }

    fun sendNote(codes: List<String>, text: String) {
        val now = System.currentTimeMillis()
        for (c in codes) {
            db().collection("notes").document(me + "_" + c)
                .set(mapOf("from" to me, "to" to c, "ts" to now, "text" to text))
        }
    }
}
