package com.couple.attention

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore

object Repo {
    private var appCtx: Context? = null
    private var started = false
    private var baselined = false
    private val lastHandled = HashMap<String, Long>()

    lateinit var me: String

    var members by mutableStateOf(listOf<Store.Member>())
        private set

    // codes of people who have added MY code (needed for a mutual match)
    var addedMe by mutableStateOf(setOf<String>())
        private set

    private fun db() = FirebaseFirestore.getInstance()

    fun start(c: Context) {
        appCtx = c.applicationContext
        if (started) return
        started = true
        val ctx = appCtx!!
        me = Store.myCode(ctx)
        members = Store.members(ctx)

        db().collection("users").whereArrayContains("contacts", me)
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    addedMe = snap.documents.map { it.id }.toSet()
                }
            }

        db().collection("pings").whereEqualTo("to", me)
            .addSnapshotListener { snap, _ ->
                if (snap == null || snap.metadata.isFromCache) return@addSnapshotListener
                for (ch in snap.documentChanges) {
                    if (ch.type == DocumentChange.Type.REMOVED) continue
                    val d = ch.document
                    val from = d.getString("from") ?: continue
                    val ts = d.getLong("ts") ?: continue
                    val last = lastHandled[from] ?: 0L
                    if (ts <= last) continue
                    lastHandled[from] = ts
                    if (!baselined) continue
                    val m = members.firstOrNull { it.code == from } ?: continue
                    Alerts.trigger(ctx, m.name)
                }
                baselined = true
            }

        publishContacts()
    }

    private fun publishContacts() {
        try {
            db().collection("users").document(me)
                .set(mapOf("contacts" to members.map { it.code }))
        } catch (e: Exception) {
        }
    }

    fun addMember(name: String, code: String) {
        members = members + Store.Member(name, code)
        appCtx?.let { Store.saveMembers(it, members) }
        publishContacts()
    }

    fun removeMember(code: String) {
        members = members.filter { it.code != code }
        appCtx?.let { Store.saveMembers(it, members) }
        publishContacts()
    }

    fun send(codes: List<String>) {
        val now = System.currentTimeMillis()
        for (c in codes) {
            db().collection("pings").document(me + "_" + c)
                .set(mapOf("from" to me, "to" to c, "ts" to now))
        }
    }
}
