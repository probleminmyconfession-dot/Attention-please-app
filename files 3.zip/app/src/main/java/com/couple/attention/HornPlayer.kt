package com.couple.attention

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.min

object HornPlayer {
    private var track: AudioTrack? = null
    private var appCtx: Context? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun saw(f: Double, t: Double): Double = 2.0 * ((t * f) % 1.0) - 1.0
    private fun sq(f: Double, t: Double): Double = if ((t * f) % 1.0 < 0.5) 1.0 else -1.0

    fun play(ctx: Context) {
        appCtx = ctx.applicationContext
        stop()
        try {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.setStreamVolume(
                AudioManager.STREAM_ALARM,
                am.getStreamMaxVolume(AudioManager.STREAM_ALARM),
                0
            )
        } catch (e: Exception) {
        }

        val sr = 44100
        val total = sr * 5
        val data = ShortArray(total)
        for (i in 0 until total) {
            val t = i.toDouble() / sr
            val ph = t % 0.65
            var env = 0.0
            if (ph < 0.5) {
                env = min(1.0, ph / 0.02) * min(1.0, (0.5 - ph) / 0.02)
            }
            var v = (saw(330.0, t) + sq(415.0, t) + saw(660.0, t)) / 2.0
            v = (v * env).coerceIn(-1.0, 1.0)
            data[i] = (v * 32767).toInt().toShort()
        }

        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(total * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, data.size)
            t.play()
            track = t
        } catch (e: Exception) {
        }

        try {
            val vib = ctx.getSystemService(Vibrator::class.java)
            val pattern = ArrayList<Long>()
            pattern.add(0L)
            for (i in 0 until 7) {
                pattern.add(400L)
                pattern.add(250L)
            }
            vib.vibrate(VibrationEffect.createWaveform(pattern.toLongArray(), -1))
        } catch (e: Exception) {
        }

        handler.postDelayed({ stop() }, 5200)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        try {
            track?.stop()
        } catch (e: Exception) {
        }
        try {
            track?.release()
        } catch (e: Exception) {
        }
        track = null
        try {
            appCtx?.getSystemService(Vibrator::class.java)?.cancel()
        } catch (e: Exception) {
        }
    }
}
