package com.couple.attention

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class AlertActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val name = intent.getStringExtra("name") ?: "Koi"
        setContent {
            AlertScreen(name) {
                HornPlayer.stop()
                finish()
            }
        }
    }
}

@Composable
fun AlertScreen(name: String, onClose: () -> Unit) {
    var left by remember { mutableStateOf(5) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left -= 1
        }
        onClose()
    }
    val t = rememberInfiniteTransition(label = "alert")
    val flash by t.animateFloat(
        initialValue = 0f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "flash"
    )
    val rot by t.animateFloat(
        initialValue = -14f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(180), RepeatMode.Reverse),
        label = "rot"
    )

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFFFF3B5C)),
        contentAlignment = Alignment.Center
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = flash)))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("📢", fontSize = 96.sp, modifier = Modifier.rotate(rot))
            Text(
                "$name bula rahe hain! 💌",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
            Text("$left sec", color = Color.White, fontSize = 20.sp)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFFFF3B5C)
                )
            ) {
                Text("Theek hai 👍", fontWeight = FontWeight.Bold)
            }
        }
    }
}
