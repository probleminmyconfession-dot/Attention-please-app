package com.couple.attention

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap

object Alerts {
    fun trigger(ctx: Context, name: String) {
        HornPlayer.play(ctx)

        val intent = Intent(ctx, AlertActivity::class.java).apply {
            putExtra("name", name)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pi = PendingIntent.getActivity(
            ctx, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("alert", "Attention alert", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)

            val n = Notification.Builder(ctx, "alert")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(name + " bula rahe hain!")
                .setContentText("Dekhne ke liye tap karo")
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(2, n)
        } catch (e: Exception) {
        }

        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
        }
    }

    // Normal notification (horn nahi). Bhejne wale ki profile photo ho to dikhegi.
    fun note(ctx: Context, fromCode: String, name: String, text: String, photoB64: String?) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("notes", "Messages", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)

            val open = Intent(ctx, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val pi = PendingIntent.getActivity(
                ctx, 3, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val b = Notification.Builder(ctx, "notes")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(name)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)

            if (photoB64 != null) {
                val bmp: Bitmap? = ImageUtil.decode(photoB64)
                if (bmp != null) b.setLargeIcon(bmp)
            }
            nm.notify(100 + Math.abs(fromCode.hashCode() % 1000), b.build())
        } catch (e: Exception) {
        }
    }
}
