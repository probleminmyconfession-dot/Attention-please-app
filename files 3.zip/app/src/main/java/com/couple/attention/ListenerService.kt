package com.couple.attention

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class ListenerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("service", "Background service", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "service")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Attention chal raha hai")
            .setContentText("Partner ke bulane ka intezaar...")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        Repo.start(this)
        return START_STICKY
    }
}
