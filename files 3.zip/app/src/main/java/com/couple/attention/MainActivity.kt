package com.couple.attention

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Red = Color(0xFFFF3B5C)
private val RedDark = Color(0xFFC81E3E)
private val PinkLight = Color(0xFFFFE3EA)
private val PinkMid = Color(0xFFFFD3DD)
private val Muted = Color(0xFFB08A95)
private val Ink = Color(0xFF3A2A30)
private val Green = Color(0xFF16A34A)
private val avColors = listOf(
    Color(0xFFFF7A93), Color(0xFFFFB02E), Color(0xFF4CC9A4),
    Color(0xFF6AA9FF), Color(0xFFB48CFF), Color(0xFFFF8FD0)
)

class MainActivity : ComponentActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startSvc() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        Repo.start(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startSvc()
        }
        setContent { MainScreen() }
    }

    private fun startSvc() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, ListenerService::class.java))
        } catch (e: Exception) {
        }
    }
}

@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var showAdd by remember { mutableStateOf(false) }
    var nameIn by remember { mutableStateOf("") }
    var codeIn by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0f) }
    var cooling by remember { mutableStateOf(false) }
    var left by remember { mutableStateOf(0) }

    LaunchedEffect(msg) {
        if (msg.isNotEmpty()) {
            delay(4000)
            msg = ""
        }
    }

    val members = Repo.members
    val addedMe = Repo.addedMe
    val effTarget = if (target == "all" || members.any { it.code == target }) target else ""

    val inf = rememberInfiniteTransition(label = "bob")
    val bob by inf.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "bobf"
    )

    fun startCooldown() {
        cooling = true
        scope.launch {
            val s = System.currentTimeMillis()
            while (true) {
                val el = System.currentTimeMillis() - s
                if (el >= 5000) break
                progress = el / 5000f
                left = ((5000 - el) / 1000).toInt() + 1
                delay(30)
            }
            progress = 0f
            cooling = false
        }
    }

    fun press() {
        if (effTarget.isEmpty()) {
            msg = "Pehle chuno kisko bhejna hai 👆"
            return
        }
        val targets = members.filter {
            it.code in addedMe && (effTarget == "all" || it.code == effTarget)
        }
        if (targets.isEmpty()) {
            msg = if (effTarget == "all") "Koi connected member nahi hai. Pehle code add karo 💕"
            else "Ye member abhi connected nahi hai ⏳"
            return
        }
        Repo.send(targets.map { it.code })
        msg = "Bhej diya 📤 " + targets.joinToString(", ") { it.name }
        target = ""
        startCooldown()
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
          Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // top bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(PinkLight)
                            .clickable {
                                clip.setText(AnnotatedString(Repo.me))
                                Toast.makeText(ctx, "Code copy ho gaya", Toast.LENGTH_SHORT).show()
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("Mera code 💖 (tap=copy)", fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold)
                        Text(Repo.me, fontSize = 22.sp, color = Red, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    }
                    Button(
                        onClick = { showAdd = !showAdd; err = "" },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Red),
                        modifier = Modifier.border(3.dp, Red, CircleShape)
                    ) {
                        Text("+ Add code", fontWeight = FontWeight.Black)
                    }
                }

                // add panel
                if (showAdd) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFFFFF7F9))
                            .border(2.dp, Color(0xFFFFB3C3), RoundedCornerShape(22.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = nameIn,
                            onValueChange = { nameIn = it.take(20) },
                            label = { Text("Naam (jaise Mummy, Riya)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = codeIn,
                            onValueChange = { codeIn = it.uppercase().take(6) },
                            label = { Text("Unka code") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (err.isNotEmpty()) {
                            Text(err, color = Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                val n = nameIn.trim()
                                val c = codeIn.trim().uppercase()
                                when {
                                    n.isEmpty() -> err = "Naam likho."
                                    c.length != 6 -> err = "Code 6 akshar ka hona chahiye."
                                    c == Repo.me -> err = "Ye to aapka apna code hai."
                                    members.any { it.code == c } -> err = "Ye code pehle se added hai."
                                    else -> {
                                        Repo.addMember(n, c)
                                        nameIn = ""
                                        codeIn = ""
                                        err = ""
                                        showAdd = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Add member 💕", fontWeight = FontWeight.Black)
                        }
                    }
                }

                // chips
                if (members.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val allSel = effTarget == "all"
                        Text(
                            "👥 Sabko",
                            color = if (allSel) Color.White else Muted,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (allSel) Red else Color.White)
                                .border(2.dp, if (allSel) Red else PinkMid, RoundedCornerShape(50))
                                .clickable { target = "all" }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                        members.forEach { m ->
                            val sel = effTarget == m.code
                            val ok = m.code in addedMe
                            Text(
                                m.name,
                                color = if (sel) Color.White else Muted,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(if (sel) Red else Color.White)
                                    .border(2.dp, if (sel) Red else PinkMid, RoundedCornerShape(50))
                                    .clickable { target = m.code }
                                    .padding(horizontal = 14.dp, vertical = 7.dp)
                                    .then(if (ok) Modifier else Modifier.scale(0.95f))
                            )
                        }
                    }
                }

                // big button with ring
                Box(
                    modifier = Modifier
                        .size(250.dp)
                        .align(Alignment.CenterHorizontally),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = 14.dp.toPx()
                        drawCircle(PinkMid, radius = size.minDimension / 2 - w / 2, style = Stroke(w))
                        if (cooling) {
                            drawArc(
                                color = Red,
                                startAngle = -90f,
                                sweepAngle = 360f * progress,
                                useCenter = false,
                                topLeft = Offset(w / 2, w / 2),
                                size = Size(size.width - w, size.height - w),
                                style = Stroke(w, cap = StrokeCap.Round)
                            )
                        }
                    }
                    Button(
                        onClick = { press() },
                        enabled = !cooling,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Red,
                            contentColor = Color.White,
                            disabledContainerColor = Color(0xFFFFB3C3),
                            disabledContentColor = Color.White
                        ),
                        modifier = Modifier
                            .size(204.dp)
                            .scale(if (cooling) 1f else bob)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("📢", fontSize = 48.sp)
                            Text(
                                if (cooling) "Ruko... $left"
                                else when (effTarget) {
                                    "" -> "Pehle chuno 👆"
                                    "all" -> "Sabko bulao!"
                                    else -> (members.firstOrNull { it.code == effTarget }?.name ?: "") + " ko bulao!"
                                },
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center,
                                maxLines = 2
                            )
                        }
                    }
                }

                Text(
                    msg,
                    color = Muted,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                // members list
                members.forEachIndexed { i, m ->
                    val ok = m.code in addedMe
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .border(2.dp, PinkLight, RoundedCornerShape(20.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(avColors[i % avColors.size]),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                m.name.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(m.name, color = Ink, fontWeight = FontWeight.Black)
                            Text(
                                if (ok) "✅ Connected" else "⏳ Unhone aapka code add nahi kiya",
                                color = if (ok) Green else Muted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        TextButton(onClick = { Repo.removeMember(m.code) }) {
                            Text("✕", color = Muted)
                        }
                    }
                }

                // setup helpers
                Spacer(Modifier.height(8.dp))
                Text("⚙️ Zaroori settings (ek baar)", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = {
                    try {
                        ctx.startActivity(
                            Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + ctx.packageName)
                            )
                        )
                    } catch (e: Exception) {
                    }
                }) { Text("🔋 Battery: No restrictions karo", color = Red) }
                if (Build.VERSION.SDK_INT >= 34) {
                    TextButton(onClick = {
                        try {
                            ctx.startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                    Uri.parse("package:" + ctx.packageName)
                                )
                            )
                        } catch (e: Exception) {
                        }
                    }) { Text("📱 Full-screen alert allow karo", color = Red) }
                }
            }
            AdBanner()
          }
        }
    }
}
