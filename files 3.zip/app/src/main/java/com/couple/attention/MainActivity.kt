package com.couple.attention

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Th(
    val red: Color, val rose: Color, val hi: Color, val pink: Color, val mid: Color,
    val muted: Color, val ink: Color, val dk: Color, val faint: Color,
    val dis: Color, val dis2: Color, val bg0: Color
)

private val PinkTh = Th(
    Color(0xFFFF3B5C), Color(0xFFFF7A93), Color(0xFFFF9DB0), Color(0xFFFFE9EF), Color(0xFFFFD3DD),
    Color(0xFFB08A95), Color(0xFF3A2A30), Color(0xFFC81E3E), Color(0xFFFFF7F9),
    Color(0xFFFFB3C3), Color(0xFFE68EA3), Color(0xFFFFF0F4)
)
private val BlueTh = Th(
    Color(0xFF3B82F6), Color(0xFF7AA9FF), Color(0xFF9FC3FF), Color(0xFFE8F1FF), Color(0xFFCFE0FF),
    Color(0xFF7A90B3), Color(0xFF22304A), Color(0xFF1E5BC4), Color(0xFFF3F8FF),
    Color(0xFFA9C6FF), Color(0xFF86A9EF), Color(0xFFEAF3FF)
)
private val Green = Color(0xFF16A34A)
private val avColors = listOf(
    Color(0xFFFF7A93), Color(0xFFFFB02E), Color(0xFF4CC9A4),
    Color(0xFF6AA9FF), Color(0xFFB48CFF), Color(0xFFFF8FD0)
)
private val quickTexts = listOf(
    "Miss you 🥺", "Thinking of you 💭", "Love you 😘",
    "Good morning ☀️", "Good night 🌙", "Call me 📞"
)

class MainActivity : ComponentActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startSvc() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        Repo.start(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startSvc()
        }
        setContent { MainScreen() }
    }

    private fun startSvc() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, ListenerService::class.java))
        } catch (e: Exception) {
        }
    }
}

// ---------------------------------------------------------------- small pieces

@Composable
fun Avatar(name: String, photoB64: String?, size: Dp, idx: Int, fontSize: TextUnit = 16.sp) {
    val bmp = remember(photoB64) { photoB64?.let { ImageUtil.decode(it) } }
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(CircleShape)
        )
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(avColors[idx % avColors.size]),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.take(1).uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = fontSize
            )
        }
    }
}

@Composable
fun Pill(label: String, selected: Boolean, th: Th, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.White else th.muted,
        fontWeight = FontWeight.Black,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) th.red else Color.White)
            .border(2.dp, if (selected) th.red else th.mid, RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 7.dp)
    )
}

@Composable
fun RoundBtn(th: Th, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(2.dp, th.mid, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun CopyIcon(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val u = size.width / 24f
        val w = 2.4f * u
        drawRoundRect(
            color = color,
            topLeft = Offset(9f * u, 9f * u),
            size = Size(11f * u, 11f * u),
            cornerRadius = CornerRadius(3f * u, 3f * u),
            style = Stroke(w, cap = StrokeCap.Round)
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(4f * u, 4f * u),
            size = Size(11f * u, 11f * u),
            cornerRadius = CornerRadius(3f * u, 3f * u),
            style = Stroke(w, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun MemberChip(
    m: Store.Member, idx: Int, selected: Boolean, connected: Boolean, photo: String?,
    th: Th, onClick: () -> Unit, onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) th.red else Color.White)
            .border(2.dp, if (selected) th.red else th.mid, RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Avatar(m.name, photo, 24.dp, idx, 11.sp)
        Text(
            m.name,
            color = if (selected) Color.White else th.muted,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            maxLines = 1
        )
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (connected) Color(0xFF22C55E) else Color(0xFFE0C9CF))
        )
        if (selected) {
            Text(
                "✕",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                modifier = Modifier.clickable { onRemove() }.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun PartnerCard(
    m: Store.Member, connected: Boolean, photo: String?, lastMsg: String?,
    th: Th, onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .border(2.dp, th.pink, RoundedCornerShape(22.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(m.name, photo, 46.dp, 0, 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(m.name, color = th.ink, fontWeight = FontWeight.Black)
            Text(
                if (connected) "✅ Connected" else "⏳ Unhone aapka code add nahi kiya",
                color = if (connected) Green else th.muted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            if (lastMsg != null) {
                Text(
                    "💌 " + lastMsg,
                    color = th.red,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(th.pink)
                .clickable { onRemove() },
            contentAlignment = Alignment.Center
        ) {
            Text("✕", color = th.red, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
    }
}

@Composable
fun BigButton(
    th: Th, stage: Dp, label: String, cooling: Boolean, progress: Float, bob: Float,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    Box(modifier = Modifier.size(stage), contentAlignment = Alignment.Center) {
        // timer ring
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = 14.dp.toPx()
            drawCircle(th.mid, radius = size.minDimension / 2 - w / 2, style = Stroke(w))
            if (cooling) {
                drawArc(
                    color = th.red,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = Offset(w / 2, w / 2),
                    size = Size(size.width - w, size.height - w),
                    style = Stroke(w, cap = StrokeCap.Round)
                )
            }
        }
        // 3D button
        Box(
            modifier = Modifier
                .size(stage * 0.82f)
                .scale(if (cooling) 1f else bob)
                .pointerInput(cooling) {
                    detectTapGestures(
                        onPress = {
                            if (!cooling) {
                                pressed = true
                                tryAwaitRelease()
                                pressed = false
                            }
                        },
                        onTap = { if (!cooling) onClick() }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val r = size.minDimension / 2 - 10.dp.toPx()
                val cx = size.width / 2
                val cy = size.height / 2
                val down = if (pressed) 7.dp.toPx() else 0f
                val depth = 8.dp.toPx()
                drawCircle(
                    color = if (cooling) th.dis2 else th.dk,
                    radius = r,
                    center = Offset(cx, cy + depth)
                )
                val brush = if (cooling) SolidColor(th.dis) else Brush.radialGradient(
                    colors = listOf(th.hi, th.red),
                    center = Offset(cx - r * 0.3f, cy - r * 0.4f + down),
                    radius = r * 1.3f
                )
                drawCircle(brush = brush, radius = r, center = Offset(cx, cy + down))
            }
            Column(
                modifier = Modifier.offset(y = if (pressed) 7.dp else 0.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("📢", fontSize = (stage.value * 0.18f).sp)
                Text(
                    label,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }
    }
}

@Composable
fun QuickTray(th: Th, onSend: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(th.faint)
            .border(1.5.dp, th.pink, RoundedCornerShape(18.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            "💌 Chhote messages · sirf notification, horn nahi",
            fontSize = 10.sp,
            color = th.muted,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        quickTexts.chunked(3).forEach { r ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                r.forEach { t ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.White)
                            .border(1.5.dp, th.mid, RoundedCornerShape(50))
                            .clickable { onSend(t) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            t,
                            color = th.red,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            lineHeight = 13.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermBtn(text: String, th: Th, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(th.faint)
            .border(1.5.dp, th.dis, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = th.red,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 10.sp,
            lineHeight = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, hint: String, th: Th) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(hint) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = th.red,
            unfocusedBorderColor = th.mid,
            focusedLabelColor = th.red
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun PrimaryBtn(label: String, th: Th, filled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (filled) th.red else Color.White,
            contentColor = if (filled) Color.White else th.red
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (filled) Modifier else Modifier.border(2.dp, th.mid, RoundedCornerShape(16.dp)))
    ) {
        Text(label, fontWeight = FontWeight.Black)
    }
}

@Composable
fun SheetBox(th: Th, title: String, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x5A3A2A30))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(horizontal = 18.dp)
                .padding(top = 10.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(44.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(th.mid)
            )
            Text(title, fontWeight = FontWeight.Black, fontSize = 18.sp, color = th.ink)
            content()
        }
    }
}

// ---------------------------------------------------------------- main screen

@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var section by remember { mutableStateOf(Store.section(ctx)) }
    var sheet by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var nameIn by remember { mutableStateOf("") }
    var codeIn by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var tmpName by remember { mutableStateOf("") }
    var tmpPhoto by remember { mutableStateOf("") }
    var confirmM by remember { mutableStateOf<Store.Member?>(null) }
    var target by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0f) }
    var cooling by remember { mutableStateOf(false) }
    var left by remember { mutableStateOf(0) }
    var copied by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val b64 = withContext(Dispatchers.Default) { ImageUtil.profileBase64(ctx, uri) }
                if (b64 != null) tmpPhoto = b64 else Toast.makeText(ctx, "Photo load nahi hui", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(msg) {
        if (msg.isNotEmpty()) {
            delay(3500)
            msg = ""
        }
    }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1200)
            copied = false
        }
    }

    val isFam = section == "family"
    val th = if (isFam) BlueTh else PinkTh
    val all = Repo.members
    val family = all.filter { it.group != "couple" }
    val partner = all.firstOrNull { it.group == "couple" }
    val addedMe = Repo.addedMe
    val profiles = Repo.profiles
    val effTarget = if (target == "all" || family.any { it.code == target }) target else ""
    val partnerNote = partner?.let { Repo.notes[it.code] }

    val inf = rememberInfiniteTransition(label = "fx")
    val bob by inf.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "bob"
    )
    val floaty by inf.animateFloat(
        initialValue = 0f,
        targetValue = -12f,
        animationSpec = infiniteRepeatable(tween(3000), RepeatMode.Reverse),
        label = "float"
    )

    fun startCooldown() {
        cooling = true
        scope.launch {
            val s = System.currentTimeMillis()
            while (true) {
                val el = System.currentTimeMillis() - s
                if (el >= 5000) break
                progress = el / 5000f
                left = ((5000 - el) / 1000).toInt() + 1
                delay(30)
            }
            progress = 0f
            cooling = false
        }
    }

    fun doHorn(selected: List<Store.Member>, notConnectedMsg: String): Boolean {
        if (!Repo.isOnline(ctx)) {
            msg = "Internet nahi hai 📵"
            return false
        }
        val targets = selected.filter { it.code in addedMe }
        if (targets.isEmpty()) {
            msg = notConnectedMsg
            return false
        }
        Repo.send(targets.map { it.code })
        msg = "Bhej diya 📤 " + targets.joinToString(", ") { it.name }
        startCooldown()
        return true
    }

    fun pressBig() {
        if (isFam) {
            if (effTarget.isEmpty()) {
                msg = "Pehle chuno kisko bhejna hai 👆"
                return
            }
            val selected = family.filter { effTarget == "all" || it.code == effTarget }
            val notConn = if (effTarget == "all") "Koi connected member nahi hai 💕"
            else "Ye member abhi connected nahi hai ⏳"
            if (doHorn(selected, notConn)) target = ""
        } else {
            if (partner == null) {
                msg = "Pehle partner add karo 💕"
                return
            }
            doHorn(listOf(partner), "Partner ne abhi aapka code add nahi kiya ⏳")
        }
    }

    fun sendQuick(text: String) {
        if (partner == null) {
            msg = "Pehle partner add karo 💕"
            return
        }
        if (partner.code !in addedMe) {
            msg = "Partner ne abhi aapka code add nahi kiya ⏳"
            return
        }
        if (!Repo.isOnline(ctx)) {
            msg = "Internet nahi hai 📵"
            return
        }
        Repo.sendNote(listOf(partner.code), text)
        msg = "Bhej diya 💌 " + text
    }

    fun addClick() {
        val n = nameIn.trim()
        val c = codeIn.trim().uppercase()
        when {
            n.isEmpty() -> err = "Naam likho."
            c.length != 6 -> err = "Code 6 akshar ka hona chahiye."
            c == Repo.me -> err = "Ye to aapka apna code hai."
            all.any { it.code == c } -> err = "Ye code pehle se added hai."
            section == "couple" && partner != null -> err = "Couple mein sirf ek partner ho sakta hai."
            else -> {
                Repo.addMember(n, c, if (section == "couple") "couple" else "family")
                nameIn = ""
                codeIn = ""
                err = ""
                sheet = ""
            }
        }
    }

    fun openAdd() {
        nameIn = ""
        codeIn = ""
        err = ""
        sheet = "add"
    }

    fun openProfile() {
        tmpName = Repo.myName
        tmpPhoto = Repo.myPhoto
        sheet = "profile"
    }

    fun askRemove(m: Store.Member) {
        confirmM = m
        sheet = "confirm"
    }

    val deco = if (isFam) listOf("💙", "✨", "☁️") else listOf("💗", "✨", "🌸")

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(th.bg0, Color.White), endY = 1500f))
            ) {
                Text(
                    deco[0], fontSize = 22.sp,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp, bottom = 80.dp)
                        .graphicsLayer { translationY = floaty }.alpha(0.5f)
                )
                Text(
                    deco[1], fontSize = 22.sp,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                        .graphicsLayer { translationY = -floaty }.alpha(0.5f)
                )
                Text(
                    deco[2], fontSize = 22.sp,
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 150.dp)
                        .graphicsLayer { translationY = floaty }.alpha(0.5f)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp)
                        .padding(top = 8.dp, bottom = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // ---------------- header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.clickable { openProfile() }) {
                                Avatar(Repo.myName.ifEmpty { "Me" }, Repo.myPhoto.ifEmpty { null }, 40.dp, 0)
                            }
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(th.pink)
                                    .padding(start = 12.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Column {
                                    Text("Mera code 💖", fontSize = 10.sp, color = th.muted, fontWeight = FontWeight.ExtraBold)
                                    Text(
                                        Repo.me, fontSize = 17.sp, color = th.red,
                                        fontWeight = FontWeight.Black, letterSpacing = 3.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.White)
                                        .clickable {
                                            clip.setText(AnnotatedString(Repo.me))
                                            copied = true
                                            Toast.makeText(ctx, "Code copy ho gaya", Toast.LENGTH_SHORT).show()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (copied) Text("✓", color = th.red, fontWeight = FontWeight.Black)
                                    else CopyIcon(th.red)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (isFam || partner == null) {
                                RoundBtn(th, { openAdd() }) {
                                    Text("＋", color = th.red, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                }
                            }
                            Box {
                                RoundBtn(th, { menuOpen = true }) {
                                    Text("⋮", color = th.red, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                }
                                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                    DropdownMenuItem(
                                        text = { Text("👤 Profile", fontWeight = FontWeight.Bold) },
                                        onClick = { menuOpen = false; openProfile() }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("👥 Members", fontWeight = FontWeight.Bold) },
                                        onClick = { menuOpen = false; sheet = "members" }
                                    )
                                }
                            }
                        }
                    }

                    // ---------------- section tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                    ) {
                        Pill("💑 Couple", !isFam, th) {
                            section = "couple"; Store.setSection(ctx, "couple")
                        }
                        Pill("👨‍👩‍👧 Family", isFam, th) {
                            section = "family"; Store.setSection(ctx, "family")
                        }
                    }

                    // ---------------- middle
                    BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        val showTray = !isFam && partner != null
                        val reserved = if (showTray) 235.dp else 135.dp
                        val stage = maxOf(130.dp, minOf(228.dp, maxHeight - reserved))

                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceEvenly,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (isFam) {
                                if (family.isEmpty()) {
                                    Text(
                                        "Upar ＋ dabake family ka code add karo 💕",
                                        color = th.muted, fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp, textAlign = TextAlign.Center
                                    )
                                } else {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            "👥 Sabko",
                                            color = if (effTarget == "all") Color.White else th.muted,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 14.sp,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(50))
                                                .background(if (effTarget == "all") th.red else Color.White)
                                                .border(2.dp, if (effTarget == "all") th.red else th.mid, RoundedCornerShape(50))
                                                .clickable { target = "all" }
                                                .padding(horizontal = 14.dp, vertical = 9.dp)
                                        )
                                        family.forEachIndexed { i, m ->
                                            MemberChip(
                                                m, i, effTarget == m.code, m.code in addedMe, profiles[m.code], th,
                                                onClick = { target = m.code },
                                                onRemove = { askRemove(m) }
                                            )
                                        }
                                    }
                                }
                            } else {
                                if (partner == null) {
                                    Text(
                                        "Abhi partner add nahi hai 💕\nUpar ＋ dabake naam aur code daalo.",
                                        color = th.muted, fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp, textAlign = TextAlign.Center
                                    )
                                } else {
                                    PartnerCard(
                                        partner, partner.code in addedMe, profiles[partner.code],
                                        partnerNote?.text, th
                                    ) { askRemove(partner) }
                                }
                            }

                            BigButton(
                                th = th,
                                stage = stage,
                                label = if (cooling) "Ruko... $left"
                                else if (isFam) {
                                    when (effTarget) {
                                        "" -> "Pehle chuno 👆"
                                        "all" -> "Sabko bulao!"
                                        else -> (family.firstOrNull { it.code == effTarget }?.name ?: "") + " ko bulao!"
                                    }
                                } else {
                                    if (partner != null) partner.name + " ko bulao!" else "Partner add karo 💕"
                                },
                                cooling = cooling,
                                progress = progress,
                                bob = bob,
                                onClick = { pressBig() }
                            )

                            Text(
                                msg,
                                color = th.muted,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                modifier = Modifier.fillMaxWidth().height(18.dp)
                            )

                            if (showTray) {
                                QuickTray(th) { sendQuick(it) }
                            }
                        }
                    }

                    // ---------------- permissions (screen par hi)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PermBtn("🔋 Battery: No restrictions karo", th, Modifier.weight(1f)) {
                            try {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                        Uri.parse("package:" + ctx.packageName)
                                    )
                                )
                            } catch (e: Exception) {
                            }
                        }
                        PermBtn("📱 Full-screen alert allow karo", th, Modifier.weight(1f)) {
                            if (Build.VERSION.SDK_INT >= 34) {
                                try {
                                    ctx.startActivity(
                                        Intent(
                                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                            Uri.parse("package:" + ctx.packageName)
                                        )
                                    )
                                } catch (e: Exception) {
                                }
                            } else {
                                Toast.makeText(ctx, "Is Android par ye alag se allow karne ki zaroorat nahi", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    AdBanner()
                }

                // ---------------- sheets
                if (sheet == "add") {
                    SheetBox(th, if (isFam) "Family member add karo 👨‍👩‍👧" else "Partner add karo 💑", { sheet = "" }) {
                        Field(nameIn, { nameIn = it.take(20) }, "Naam (jaise Mummy, Riya)", th)
                        Field(codeIn, { codeIn = it.uppercase().take(6) }, "Unka code", th)
                        if (err.isNotEmpty()) {
                            Text(err, color = th.red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        PrimaryBtn("Add 💕", th) { addClick() }
                    }
                }
                if (sheet == "profile") {
                    SheetBox(th, "Mera profile 👤", { sheet = "" }) {
                        Box(
                            modifier = Modifier.size(96.dp).clickable {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        ) {
                            Avatar(tmpName.ifEmpty { "Me" }, tmpPhoto.ifEmpty { null }, 96.dp, 0, 32.sp)
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(th.red)
                                    .border(3.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Text("📷", fontSize = 13.sp) }
                        }
                        Field(tmpName, { tmpName = it.take(20) }, "Mera naam", th)
                        PrimaryBtn("Save 💖", th) {
                            Repo.setProfile(tmpName.trim(), tmpPhoto)
                            sheet = ""
                            msg = "Profile save ho gaya 💖"
                        }
                    }
                }
                if (sheet == "members") {
                    SheetBox(th, "Members 👥", { sheet = "" }) {
                        if (all.isEmpty()) {
                            Text("Abhi koi member nahi hai.", color = th.muted, fontWeight = FontWeight.Bold)
                        }
                        Column(
                            modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            all.forEachIndexed { i, m ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(18.dp))
                                        .border(2.dp, th.pink, RoundedCornerShape(18.dp))
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Avatar(m.name, profiles[m.code], 38.dp, i, 15.sp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            m.name + if (m.group == "couple") " 💑" else "",
                                            color = th.ink, fontWeight = FontWeight.Black
                                        )
                                        Text(
                                            if (m.code in addedMe) "✅ Connected" else "⏳ Unhone aapka code add nahi kiya",
                                            color = if (m.code in addedMe) Green else th.muted,
                                            fontSize = 12.sp, fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        "✕", color = th.muted, fontWeight = FontWeight.Black, fontSize = 16.sp,
                                        modifier = Modifier.clickable { askRemove(m) }.padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                if (sheet == "confirm") {
                    val cm = confirmM
                    SheetBox(th, "Hatana hai?", { sheet = "" }) {
                        Text(
                            (cm?.name ?: "") + " ko hata dein?",
                            color = th.muted, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center
                        )
                        PrimaryBtn("Haan, hatao", th) {
                            if (cm != null) Repo.removeMember(cm.code)
                            sheet = ""
                        }
                        PrimaryBtn("Nahi", th, filled = false) { sheet = "" }
                    }
                }
            }
        }
    }
}
